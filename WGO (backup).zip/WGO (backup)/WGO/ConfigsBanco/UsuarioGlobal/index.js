let userId = null;

export function setUser(id) {
  userId = id;
}
export function getUser() {
  return userId;
}