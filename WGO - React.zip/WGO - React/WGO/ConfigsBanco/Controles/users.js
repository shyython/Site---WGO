import express from 'express';
import { getUsers, addUser, getEvent } from './user.js';
const router = express.Router();

router.get('/', getUsers);

router.post('/', addUser);

router.get('/eventos', getEvent)

export default router;